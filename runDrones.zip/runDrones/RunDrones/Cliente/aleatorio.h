#ifndef ALEATORIO_H_
#define ALEATORIO_H_
#include <stdlib.h>

#define RANGO 2000

/**
 * Generar un numero aleatorio entre 0 y 1
 * @return numero aleatorio entre 0 y 1	
*/
float aleatorio();

#endif